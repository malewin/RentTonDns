// arrays of lists

let Ul = [
    "song.ton", // site
    "hire.ton", // site
    "mage.ton", // game
    "poet.ton", // prof
    "druid.ton", // game
    "actor.ton", // prof
    "tutor.ton", // prof
    "rogue.ton", // game
    "thief.ton", // wallet
    "saver.ton", // utility
    "editor.ton", // prof
    "storer.ton", // utility
    "minter.ton", // utility
    "writer.ton", // prof
    "singer.ton", // prof
    "sender.ton", // utility
    "dancer.ton", // prof
    "funpay.ton", // other
    "farmer.ton", // prof
    "reader.ton", // utility
    "switch.ton", // utility
    "waiter.ton", // prof
    "author.ton", // service
    "worker.ton", // utility
    "healer.ton", // game
    "webdev.ton", // prof
    "buffer.ton", // utility
    "tondev.ton", // other
    "shaman.ton", // game
    "visitor.ton", // service
    "actress.ton", // prof
    "cleaner.ton", // prof
    "transit.ton", // service
    "trainer.ton", // prof
    "teacher.ton", // prof
    "booster.ton", // utility
    "courier.ton", // prof
    "soldier.ton", // prof
    "warlock.ton", // game
    "athlete.ton", // prof
    "emitter.ton", // utility
    "fighter.ton", // prof
    "printer.ton", // utility
    "student.ton", // site
    "paladin.ton", // game
    "warrior.ton", // game
    "counter.ton", // utility
    "follower.ton",
    "informer.ton", // prof
    "notifier.ton", // prof
    "receiver.ton", // utility
    "streamer.ton", // prof
    "reviewer.ton", // prof
    "repeater.ton", // utility
    "learning.ton", // site
    "operator.ton", // prof
    "educator.ton", // prof
    "mechanic.ton", // prof
    "promoter.ton", // prof
    "composer.ton", // prof
    "traveler.ton", // prof
    "musician.ton", // prof
    "employer.ton", // prof
    "publisher.ton", // prof
    "librarian.ton", // prof
    "organizer.ton", // prof
    "landowner.ton", // prof
    "materials.ton", // site
    "policeman.ton", // prof
    "paramedic.ton", // prof
    "xn--80ahc.ton", // punycode
    "separator.ton", // utility
    "assistant.ton", // prof
    "podcaster.ton", // prof
    "regulator.ton", // prof
    "registrar.ton", // prof
    "installer.ton", // utility
    "informant.ton", // prof
    "presenter.ton", // prof
    "ticketpay.ton", // site
    "sportsman.ton", // prof
    "protester.ton", // prof
    "volunteer.ton", // prof
    "colleague.ton", // other
    "pythondev.ton", // prof
    "secretary.ton", // prof
    "recruiter.ton", // prof
    "decorator.ton", // prof
    "maximalist.ton", // other
    "pharmacist.ton", // prof
    "informator.ton", // prof
    "damagedeal.ton", // game
    "xn--d1ad3a.ton", // punycode
    "dnsrentals.ton", // site
    "guildwars2.ton", // game
    "news-world.ton", // other
    "autoseller.ton", // prof
    "programbot.ton", // service
    "domainrent.ton", // site
    "filmcritic.ton", // prof
    "typesetter.ton", // prof
    "politician.ton", // prof
    "biographer.ton", // prof
    "missionary.ton", // prof
    "eliminator.ton", // prof
    "campaigner.ton", // prof
    "undertaker.ton", // prof
    "unemployed.ton", // prof
    "adventurer.ton", // prof
    "subscriber.ton", // utility
    "auctioneer.ton", // prof
    "taxidriver.ton", // prof
    "advertiser.ton", // prof
    "negotiator.ton", // prof
    "foodcritic.ton", // prof
    "technician.ton", // prof
    "downloader.ton", // utility
    "prosecutor.ton", // prof
    "arbitrator.ton", // prof
    "competitor.ton", // prof
    "dns-server.ton", // utility
    "ip-address.ton", // utility
    "subnetmask.ton", // utility
    "playwright.ton", // prof
    "artdirector.ton", // prof
    "audioeditor.ton", // prof
    "tvpresenter.ton", // prof
    "e-signature.ton", // service
    "footballist.ton", // prof
    "bristleback.ton", // game dota
    "beastmaster.ton", // game dote
    "participant.ton", // service
    "soliditydev.ton", // prof
    "demonhunter.ton", // game wow
    "deathknight.ton", // game wow
    "neural-love.ton", // service
    "videoeditor.ton", // prof
    "ui-designer.ton", // prof
    "dnsnotifier.ton", // service
    "aviatickets.ton", // site
    "deliveryboy.ton", // prof
    "metabuilder.ton", // other
    "perfomancer.ton", // prof
    "implementer.ton", // prof
    "diplomatist.ton", // prof
    "arbitrament.ton", // service
    "audiostudio.ton", // service
    "warnermusic.ton", // other
    "yachtrental.ton", // service
    "moneystream.ton", // other
    "marrymelove.ton", // other
    "besttrainer.ton", // other
    "data-buffer.ton", // utility
    "accountancy.ton", // site
    "news-russia.ton", // site
    "vpn-service.ton", // utility
    "ai-engineer.ton", // prof
    "aviatransit.ton", // site
    "autotransit.ton", // site
    "maptracking.ton", // service
    "cosmetician.ton", // prof
    "misanthrope.ton", // other
    "disappearer.ton", // other
    "ux-designer.ton", // prof
    "conspirator.ton", // utility
    "recommender.ton", // utility
    "mockingbird.ton", // other
    "tonfollower.ton", // other
    "witchdoctor.ton", // game dota
    "neverwinter.ton", // game
    "hairstylist.ton", // prof
    "contentment.ton", // prof
    "demographer.ton", // prof
    "neurologist.ton", // prof
    "philologist.ton", // prof
    "physiatrist.ton", // prof
    "mountaineer.ton", // prof
    "transmitter.ton", // utility
    "audiobooker.ton", // service
    "dhcp-server.ton", // utility
    "mirrorsedge.ton", // game
    "dns-domains.ton", // service
    "destitution.ton", // other
    "blackdesert.ton", // game
    "pathofexile.ton", // game
    "musiccritic.ton", // prof
    "e-sportsman.ton", // prof
    "fashionshow.ton", // site
    "audiologist.ton", // prof
    "voguereview.ton", // site
    "confiscator.ton", // prof
    "perpetrator.ton", // prof
    "notificator.ton", // utility
    "xn--80a1acny.ton", // punycode
    "loadbalancer.ton", // utility
    "routingtable.ton", // utility
    "dreamfield3d.ton", // service neurochain
    "demonstrator.ton", // prof
    "1c-developer.ton", // prof
    "xn--90aiim0b.ton", // punycode
    "storybooster.ton", // service
    "it-recruiter.ton", // prof
    "xn--80ae0bii.ton", // punycode
    "vocalremover.ton", // service
    "turnkeyhouse.ton", // site
    "fullstackdev.ton", // prof
    "xn--c1akhxjc.ton", // punycode
    "domenvarendu.ton", // site
    "arendadomena.ton", // site
    "bladeandsoul.ton", // game
    "insurance365.ton", // site
    "studyenglish.ton", // site
    "easylanguage.ton", // site
    "cyberathlete.ton", // prof
    "starconflict.ton", // game
    "deliverydrug.ton", // service
    "acquaintance.ton", // service
    "screenwriter.ton", // prof
    "traintransit.ton", // site
    "filmreviewer.ton", // prof
    "dns-hostname.ton", // utility
    "porndirector.ton", // prof
    "domainrental.ton", // site
    "merchandiser.ton", // prof
    "autoreseller.ton", // prof
    "tondnsrental.ton", // site
    "ui-developer.ton", // prof
    "calligrapher.ton", // prof
    "receptionist.ton", // prof
    "facelessvoid.ton", // game dota
    "tv-presenter.ton", // prof
    "shadowshaman.ton", // game dota
    "it-architect.ton", // prof
    "entomologist.ton", // prof
    "chainmanager.ton", // prof
    "art-director.ton", // prof
    "layoutdesign.ton", // site
    "seismologist.ton", // prof
    "cartographer.ton", // prof
    "ethnographer.ton", // prof
    "productowner.ton", // service
    "experimenter.ton", // prof
    "damagedealer.ton", // game
    "obstetrician.ton", // prof
    "immunologist.ton", // prof
    "tonlibraries.ton", // utility
    "audiocreator.ton", // prof
    "socialworker.ton", // prof
    "nft-collector.ton", //  other
    "yusakumaezava.ton", // person
    "crypto-casino.ton", // site
    "ornithologist.ton", // prof
    "correspondent.ton", // prof
    "contentwriter.ton", // prof
    "sales-manager.ton", // prof
    "reconstructor.ton", // prof
    "growth-hacker.ton", // prof
    "ton-developer.ton", // prof
    "data-engineer.ton", // prof
    "telegram-news.ton", // other
    "instrumentals.ton", // site
    "gerontologist.ton", // prof
    "event-planner.ton", // utility
    "audioengineer.ton", // prof
    "it-consultant.ton", // prof
    "stadiumevents.ton", // game
    "darknetsurfer.ton", // other
    "choreographer.ton", // prof
    "php-developer.ton", // prof
    "meteorologist.ton", // prof
    "cyberwinner.ton", // site
    "playerunknown.ton", // game
    "facedetecting.ton", // service
    "enhancespeech.ton", // service neurochain
    "cyberchampion.ton", // site/wallet
    "theatrecritic.ton", // prof
    "xn--b1ak2a9bn.ton", // punycode
    "xn--d1acpjx3f.ton", // punycode
    "arendadomenov.ton", // site
    "dnsdomainrent.ton", // site
    "deliverycheck.ton", // service
    "porncameraman.ton", // prof
    "realestatebuy.ton", // site
    "chatmoderator.ton", // utility
    "chat-roulette.ton", // service
    "dappdeveloper.ton", // prof
    "cryptoanalyst.ton", // prof
    "blockchaindev.ton", // prof
    "dwarvensniper.ton", // game dota
    "songdetecting.ton", // service
    "funcdeveloper.ton", // prof
    "tactdeveloper.ton", // prof
    "civil-engineer.ton", // prof
    "rentalservices.ton", // site
    "paleontologist.ton", // prof
    "bookstoreowner.ton", // service
    "toncoinanalyst.ton", // prof
    "epidemiologist.ton", // prof
    "representative.ton", // prof
    "contentcreator.ton", // prof
    "rheumatologist.ton", // prof
    "microbiologist.ton", // prof
    "radiopresenter.ton", // prof
    "parasitologist.ton", // prof
    "layoutdesigner.ton", // prof
    "turnkeywebsite.ton", // site
    "literarycritic.ton", // prof
    "cyberpoliceman.ton", // other
    "webdevelopment.ton", // prof
    "content-writer.ton", // prof
    "cyber-squatter.ton", // prof
    "cyber-scuatter.ton", // other
    "cryptopromoter.ton", // other
    "turnkeyproject.ton", // site
    "xn--80ataoec1a.ton", // punycode
    "funeralservice.ton", // site
    "assassinscreed.ton", // game
    "universalmusic.ton", // site
    "passportoffice.ton", // site
    "xn--7-2sn3401h.ton", // punycode
    "xn--8-2sn3401h.ton", // punycode
    "realestatesale.ton", // site
    "storiesbooster.ton", // utility
    "dnsdomainsrent.ton", // site
    "xn--b1addnjx7d.ton", // punycode
    "portforwarding.ton", // utility
    "fortnitemobile.ton", // game
    "vintongraycerf.ton", // person
    "motiondesigner.ton", // prof
    "procrastinator.ton", // other
    "xn--80aqnelhdl.ton", // punycode
    "technicalwriter.ton", // prof
    "turnkeycontract.ton", // site
    "endocrinologist.ton", // prof
    "electricscooter.ton", // site
    "software-tester.ton", // prof
    "grandtheftauto5.ton", // game
    "legioncommander.ton", // game
    "phantomassassin.ton", // game
    "businessanalyst.ton", // prof
    "conservationist.ton", // other
    "turnkeybusiness.ton", // site
    "devops-engineer.ton", // prof
    "account-manager.ton", // prof
    "fashionreviewer.ton", // prof
    "softwaresupport.ton", // prof
    "clothingstylist.ton", // prof
    "xn--80aafg6avvi.ton", // punycode
    "fashiondesigner.ton", // prof
    "project-manager.ton", // prof
    "prompt-engineer.ton", // prof
    "product-manager.ton", // prof
    "content-manager.ton", // prof
    "fullstackwebdev.ton", // prof
    "contentreviewer.ton", // prof
    "customs-officer.ton", // prof
    "theelderscrolls.ton", // game
    "cyber-sportsman.ton", // prof
    "clipinterrogator.ton", // prof
    "anesthesiologist.ton", // prof
    "telegram-support.ton", // service
    "business-analyst.ton", // prof
    "financialanalyst.ton", // prof
    "dental-assistant.ton", // prof
    "restaurantcritic.ton", // prof
    "devrelationslead.ton", // prof
    "birthcertificate.ton", // other
    "worldofwarplanes.ton", // game
    "marriagecontract.ton", // other
    "xn--b1afajfl0aek.ton", // punycode
    "environmentalist.ton", // other
    "marketingmanager.ton", // prof
    "kotlin-developer.ton", // prof
    "affiliatemanager.ton", // prof
    "financial-advisor.ton", // prof
    "internet-marketer.ton", // prof
    "microsoftdesigner.ton", // service neurochain
    "supportspecialist.ton", // prof
    "software-engineer.ton", // prof
    "pixelartdiffusion.ton", // service neurochain
    "cybercompetitions.ton", // other
    "sketchmetademolab.ton", // service neurochain
    "youwillbecomeadad.ton", // other
    "shortreadablename.ton", // other
    "big-data-engineer.ton", // prof
    "marketing-manager.ton", // prof
    "financial-analyst.ton", // prof
    "community-manager.ton", // prof
    "back-end-developer.ton", // prof
    "gastroenterologist.ton", // prof
    "research-scientist.ton", // prof
    "dungeonsanddragons.ton", // game
    "physical-therapist.ton", // prof
    "reddeadredemption2.ton", // game
    "operationalmanager.ton", // prof
    "electrical-engineer.ton", // prof
    "blockchaindeveloper.ton", // prof
    "front-end-developer.ton", // prof
    "full-stack-developer.ton", // prof
    "social-media-manager.ton", // prof
    "blockchaindataanalyst.ton", // prof
    "systems-administrator.ton", // prof
    "marketing-coordinator.ton", // prof
    "it-support-specialist.ton", // prof
    "cybersecurity-analyst.ton", // prof
    "developerrelationslead.ton", // prof
    "xn--666-uc1abb94470bcac.ton", // punycode
    "xn--888-uc1abb94470bcac.ton", // punycode
    "xn--777-uc1abb94470bcac.ton", // punycode
    "blockchainfullstackdeveloper.ton" // prof
];
//professions
let list_prof = [
    "poet",
    "actor",
    "tutor",
    "editor",
    "writer",
    "singer",
    "dancer",
    "farmer",
    "waiter",
    "webdev",
    "actress",
    "cleaner",
    "trainer",
    "teacher",
    "courier",
    "soldier",
    "athlete",
    "fighter",
    "informer",
    "notifier",
    "streamer",
    "reviewer",
    "operator",
    "educator",
    "mechanic",
    "promoter",
    "composer",
    "traveler",
    "musician",
    "employer",
    "publisher",
    "librarian",
    "organizer",
    "landowner",
    "policeman",
    "paramedic",
    "assistant",
    "podcaster",
    "regulator",
    "registrar",
    "informant",
    "presenter",
    "sportsman",
    "protester",
    "volunteer",
    "pythondev",
    "secretary",
    "recruiter",
    "decorator",
    "pharmacist",
    "informator",
    "autoseller",
    "filmcritic",
    "typesetter",
    "politician",
    "biographer",
    "missionary",
    "eliminator",
    "campaigner",
    "undertaker",
    "unemployed",
    "adventurer",
    "auctioneer",
    "taxidriver",
    "advertiser",
    "negotiator",
    "foodcritic",
    "technician",
    "prosecutor",
    "arbitrator",
    "playwright",
    "artdirector",
    "audioeditor",
    "tvpresenter",
    "footballist",
    "soliditydev",
    "videoeditor",
    "ui-designer",
    "deliveryboy",
    "perfomancer",
    "implementer",
    "diplomatist",
    "ai-engineer",
    "cosmetician",
    "ux-designer",
    "hairstylist",
    "contentment",
    "demographer",
    "neurologist",
    "philologist",
    "physiatrist",
    "mountaineer",
    "musiccritic",
    "e-sportsman",
    "audiologist",
    "confiscator",
    "demonstrator",
    "1c-developer",
    "it-recruiter",
    "fullstackdev",
    "cyberathlete",
    "screenwriter",
    "filmreviewer",
    "porndirector",
    "merchandiser",
    "autoreseller",
    "ui-developer",
    "calligrapher",
    "receptionist",
    "tv-presenter",
    "it-architect",
    "entomologist",
    "chainmanager",
    "art-director",
    "seismologist",
    "cartographer",
    "ethnographer",
    "experimenter",
    "obstetrician",
    "immunologist",
    "audiocreator",
    "socialworker",
    "ornithologist",
    "correspondent",
    "contentwriter",
    "sales-manager",
    "reconstructor",
    "growth-hacker",
    "ton-developer",
    "data-engineer",
    "gerontologist",
    "audioengineer",
    "it-consultant",
    "choreographer",
    "php-developer",
    "meteorologist",
    "theatrecritic",
    "porncameraman",
    "dappdeveloper",
    "cryptoanalyst",
    "blockchaindev",
    "funcdeveloper",
    "tactdeveloper",
    "civil-engineer",
    "paleontologist",
    "toncoinanalyst",
    "epidemiologist",
    "representative",
    "contentcreator",
    "rheumatologist",
    "microbiologist",
    "radiopresenter",
    "parasitologist",
    "layoutdesigner",
    "literarycritic",
    "webdevelopment",
    "content-writer",
    "cyber-squatter",
    "motiondesigner",
    "technicalwriter",
    "endocrinologist",
    "software-tester",
    "businessanalyst",
    "devops-engineer",
    "account-manager",
    "fashionreviewer",
    "softwaresupport",
    "clothingstylist",
    "fashiondesigner",
    "project-manager",
    "prompt-engineer",
    "product-manager",
    "content-manager",
    "fullstackwebdev",
    "contentreviewer",
    "customs-officer",
    "cyber-sportsman",
    "anesthesiologist",
    "business-analyst",
    "financialanalyst",
    "dental-assistant",
    "restaurantcritic",
    "devrelationslead",
    "marketingmanager",
    "kotlin-developer",
    "affiliatemanager",
    "financial-advisor",
    "internet-marketer",
    "supportspecialist",
    "software-engineer",
    "big-data-engineer",
    "marketing-manager",
    "financial-analyst",
    "community-manager",
    "back-end-developer",
    "gastroenterologist",
    "research-scientist",
    "physical-therapist",
    "operationalmanager",
    "electrical-engineer",
    "blockchaindeveloper",
    "front-end-developer",
    "full-stack-developer",
    "social-media-manager",
    "blockchaindataanalyst",
    "systems-administrator",
    "marketing-coordinator",
    "it-support-specialist",
    "cybersecurity-analyst",
    "developerrelationslead",
    "blockchainfullstackdeveloper"
];

let list_prof_artmedia = [
    "poet",
    "actor",
    "editor",
    "writer",
    "singer",
    "dancer",
    "actress",
    "informer",
    "notifier",
    "streamer",
    "reviewer",
    "operator",
    "promoter",
    "composer",
    "musician",
    "publisher",
    "podcaster",
    "informant",
    "presenter",
    "informator",
    "filmcritic",
    "typesetter",
    "biographer",
    "advertiser",
    "playwright",
    "artdirector",
    "audioeditor",
    "tvpresenter",
    "videoeditor",
    "contentment",
    "musiccritic",
    "audiologist",
    "screenwriter",
    "filmreviewer",
    "porndirector",
    "calligrapher",
    "tv-presenter",
    "art-director",
    "audiocreator",
    "correspondent",
    "contentwriter",
    "audioengineer",
    "choreographer",
    "theatrecritic",
    "porncameraman",
    "contentcreator",
    "radiopresenter",
    "content-writer",
    "motiondesigner",
    "fashionreviewer",
    "fashiondesigner",
    "content-manager",
    "contentreviewer",
    "marketingmanager",
    "affiliatemanager",
    "social-media-manager",
];

let list_prof_it = [
    "webdev",
    "pythondev",
    "soliditydev",
    "ui-designer",
    "ai-engineer",
    "ux-designer",
    "1c-developer",
    "it-recruiter",
    "fullstackdev",
    "ui-developer",
    "it-architect",
    "chainmanager",
    "growth-hacker",
    "ton-developer",
    "data-engineer",
    "it-consultant",
    "php-developer",
    "dappdeveloper",
    "cryptoanalyst",
    "blockchaindev",
    "funcdeveloper",
    "tactdeveloper",
    "toncoinanalyst",
    "layoutdesigner",
    "webdevelopment",
    "cyber-squatter",
    "technicalwriter",
    "software-tester",
    "businessanalyst",
    "devops-engineer",
    "account-manager",
    "softwaresupport",
    "project-manager",
    "prompt-engineer",
    "product-manager",
    "fullstackwebdev",
    "devrelationslead",
    "kotlin-developer",
    "supportspecialist",
    "software-engineer",
    "big-data-engineer",
    "back-end-developer",
    "research-scientist",
    "blockchaindeveloper",
    "front-end-developer",
    "full-stack-developer",
    "blockchaindataanalyst",
    "systems-administrator",
    "marketing-coordinator",
    "it-support-specialist",
    "cybersecurity-analyst",
    "developerrelationslead",
    "blockchainfullstackdeveloper"
];

let list_prof_traditional = [
    "tutor",
    "farmer",
    "waiter",
    "cleaner",
    "trainer",
    "teacher",
    "courier",
    "soldier",
    "athlete",
    "fighter",
    "educator",
    "mechanic",
    "traveler",
    "employer",
    "librarian",
    "organizer",
    "landowner",
    "policeman",
    "assistant",
    "regulator",
    "registrar",
    "sportsman",
    "protester",
    "volunteer",
    "secretary",
    "recruiter",
    "decorator",
    "autoseller",
    "politician",
    "missionary",
    "eliminator",
    "campaigner",
    "undertaker",
    "unemployed",
    "adventurer",
    "auctioneer",
    "taxidriver",
    "negotiator",
    "foodcritic",
    "technician",
    "prosecutor",
    "arbitrator",
    "footballist",
    "deliveryboy",
    "perfomancer",
    "implementer",
    "diplomatist",
    "cosmetician",
    "hairstylist",
    "demographer",
    "philologist",
    "mountaineer",
    "e-sportsman",
    "confiscator",
    "demonstrator",
    "cyberathlete",
    "merchandiser",
    "autoreseller",
    "receptionist",
    "cartographer",
    "ethnographer",
    "experimenter",
    "socialworker",
    "sales-manager",
    "reconstructor",
    "meteorologist",
    "civil-engineer",
    "paleontologist",
    "representative",
    "literarycritic",
    "clothingstylist",
    "customs-officer",
    "cyber-sportsman",
    "business-analyst",
    "financialanalyst",
    "restaurantcritic",
    "financial-advisor",
    "internet-marketer",
    "marketing-manager",
    "financial-analyst",
    "community-manager",
    "operationalmanager",
    "electrical-engineer",
];

let list_prof_medicine = [
    "paramedic",
    "pharmacist",
    "neurologist",
    "physiatrist",
    "entomologist",
    "seismologist",
    "obstetrician",
    "immunologist",
    "ornithologist",
    "gerontologist",
    "epidemiologist",
    "rheumatologist",
    "microbiologist",
    "parasitologist",
    "endocrinologist",
    "anesthesiologist",
    "dental-assistant",
    "gastroenterologist",
    "physical-therapist",
];

//utility
let list_utility = [
    "saver",
    "storer",
    "minter",
    "sender",
    "reader",
    "switch",
    "worker",
    "buffer",
    "booster",
    "emitter",
    "printer",
    "counter",
    "follower",
    "receiver",
    "repeater",
    "separator",
    "installer",
    "subscriber",
    "downloader",
    "dns-server",
    "ip-address",
    "subnetmask",
    "data-buffer",
    "vpn-service",
    "e-signature",
    "conspirator",
    "recommender",
    "transmitter",
    "dhcp-server",
    "notificator",
    "loadbalancer",
    "routingtable",
    "dns-hostname",
    "tonlibraries",
    "event-planner",
    "chatmoderator",
    "storiesbooster",
    "portforwarding",
];
//gaming
let list_game = [
    "mage", // cl
    "druid", // cl
    "rogue", // cl
    "thief", // r
    "healer", // r
    "shaman", // cl
    "warlock", // cl
    "paladin", // cl
    "warrior", // cl
    "damagedeal", // r
    "guildwars2", // g
    "bristleback", // ch
    "beastmaster", // ch
    "demonhunter", // cl
    "deathknight", // cl
    "witchdoctor", // ch
    "neverwinter", // g
    "mirrorsedge", // g
    "blackdesert", // g
    "pathofexile", // g
    "bladeandsoul", // g
    "starconflict", // g
    "facelessvoid", // ch
    "shadowshaman", // ch
    "damagedealer", // r
    "stadiumevents", // g
    "playerunknown", // g
    "dwarvensniper", // ch
    "assassinscreed", // g
    "fortnitemobile", // g
    "grandtheftauto5", // g
    "legioncommander", // ch
    "phantomassassin", // ch
    "theelderscrolls", // g
    "worldofwarplanes", // g
    "dungeonsanddragons", // g
    "reddeadredemption2", // g
];

let list_game_classes = [
    "mage", // cl
    "druid", // cl
    "rogue", // cl
    "shaman", // cl
    "warlock", // cl
    "paladin", // cl
    "warrior", // cl
    "demonhunter", // cl
    "deathknight", // cl
];

let list_game_roles = [
    "thief", // r
    "healer", // r
    "damagedeal", // r
    "damagedealer", // r
];

let list_game_chars = [
    "bristleback", // ch
    "beastmaster", // ch
    "witchdoctor", // ch
    "facelessvoid", // ch
    "shadowshaman", // ch
    "dwarvensniper", // ch
    "legioncommander", // ch
    "phantomassassin", // ch
];

let list_game_games = [
    "guildwars2", // g
    "neverwinter", // g
    "mirrorsedge", // g
    "blackdesert", // g
    "pathofexile", // g
    "bladeandsoul", // g
    "starconflict", // g
    "stadiumevents", // g
    "playerunknown", // g
    "assassinscreed", // g
    "fortnitemobile", // g
    "grandtheftauto5", // g
    "theelderscrolls", // g
    "worldofwarplanes", // g
    "dungeonsanddragons", // g
    "reddeadredemption2", // g
];

//services
let list_service = [
    "song",
    "hire",
    "funpay",
    "transit",
    "student",
    "learning",
    "materials",
    "ticketpay",
    "dnsrentals",
    "news-world",
    "programbot",
    "domainrent",
    "neural-love",
    "dnsnotifier",
    "aviatickets",
    "arbitrament",
    "audiostudio",
    "warnermusic",
    "yachtrental",
    "accountancy",
    "news-russia",
    "aviatransit",
    "autotransit",
    "audiobooker",
    "dns-domains",
    "fashionshow",
    "voguereview",
    "dreamfield3d",
    "storybooster",
    "vocalremover",
    "turnkeyhouse",
    "domenvarendu",
    "arendadomena",
    "insurance365",
    "studyenglish",
    "easylanguage",
    "deliverydrug",
    "acquaintance",
    "traintransit",
    "domainrental",
    "tondnsrental",
    "layoutdesign",
    "crypto-casino",
    "telegram-news",
    "instrumentals",
    "enhancespeech",
    "arendadomenov",
    "dnsdomainrent",
    "deliverycheck",
    "realestatebuy",
    "chat-roulette",
    "rentalservices",
    "turnkeywebsite",
    "turnkeyproject",
    "funeralservice",
    "universalmusic",
    "passportoffice",
    "realestatesale",
    "dnsdomainsrent",
    "turnkeycontract",
    "electricscooter",
    "turnkeybusiness",
    "clipinterrogator",
    "telegram-support",
    "microsoftdesigner",
    "pixelartdiffusion",
    "sketchmetademolab"
];

let list_others = [
    "author",
    "tondev",
    "visitor",
    "colleague",
    "competitor",
    "maximalist",
    "participant",
    "metabuilder",
    "moneystream",
    "marrymelove",
    "besttrainer",
    "maptracking",
    "misanthrope",
    "disappearer",
    "mockingbird",
    "perpetrator",
    "tonfollower",
    "destitution",
    "productowner",
    "nft-collector",
    "yusakumaezava",
    "darknetsurfer",
    "cyberwinner",
    "facedetecting",
    "cyberchampion",
    "songdetecting",
    "bookstoreowner",
    "cyberpoliceman",
    "cyber-scuatter",
    "cryptopromoter",
    "vintongraycerf",
    "procrastinator",
    "conservationist",
    "birthcertificate",
    "marriagecontract",
    "environmentalist",
    "cybercompetitions",
    "youwillbecomeadad",
    "shortreadablename"
];

let list_punycode = [
    "xn--80ahc",
    "xn--d1ad3a",
    "xn--80a1acny",
    "xn--90aiim0b",
    "xn--80ae0bii",
    "xn--c1akhxjc",
    "xn--b1ak2a9bn",
    "xn--d1acpjx3f",
    "xn--80ataoec1a",
    "xn--7-2sn3401h",
    "xn--8-2sn3401h",
    "xn--b1addnjx7d",
    "xn--80aqnelhdl",
    "xn--80aafg6avvi",
    "xn--b1afajfl0aek",
    "xn--666-uc1abb94470bcac",
    "xn--888-uc1abb94470bcac",
    "xn--777-uc1abb94470bcac"
];

//generation of list_elements-links

function listElementsGeneration(listId, elementsArr) {
    for (i = 0; i < elementsArr.length; ++i) {
        let a = document.createElement('a');
        a.href = `https://dns.ton.org/#${elementsArr[i]}`;
        // a.href = `https://getgems.io/collection/EQC3dNlesgVD8YbAazcauIrXBPfiVhMMr5YYk2in0Mtsz0Bz?filter=%7B%22q%22%3A%22${list_prof_link[i]}%22%7D#search`
        a.innerText = `${elementsArr[i]}.ton`;
        a.className = `element_for_search`;
        listId.appendChild(a);
    }
}
let list1 = document.getElementById("list1");
listElementsGeneration(list1, list_prof);

let list1_1 = document.getElementById("list1_1");
listElementsGeneration(list1_1, list_prof_artmedia);

let list1_2 = document.getElementById("list1_2");
listElementsGeneration(list1_2, list_prof_it);

let list1_3 = document.getElementById("list1_3");
listElementsGeneration(list1_3, list_prof_traditional);

let list1_4 = document.getElementById("list1_4");
listElementsGeneration(list1_4, list_prof_medicine);

let list2 = document.getElementById("list2");
listElementsGeneration(list2, list_utility);

let list3 = document.getElementById("list3");
listElementsGeneration(list3, list_game);

let list3_1 = document.getElementById("list3_1");
listElementsGeneration(list3_1, list_game_classes);

let list3_2 = document.getElementById("list3_2");
listElementsGeneration(list3_2, list_game_roles);

let list3_3 = document.getElementById("list3_3");
listElementsGeneration(list3_3, list_game_chars);

let list3_4 = document.getElementById("list3_4");
listElementsGeneration(list3_4, list_game_games);

let list4 = document.getElementById("list4");
listElementsGeneration(list4, list_service);

let list5 = document.getElementById("list5");
listElementsGeneration(list5, list_others);

let list6 = document.getElementById("list6");
listElementsGeneration(list6, list_punycode);

// counter of amount elements

function counterGroup(group) {
    let count = 0;
    while (count <= group.length - 1) {
        count++;
    }
    console.log(count);
    return count;
}

function countAmountOf(nameVar, thisGroup, AllGroup) {
    nameVar.innerText = "(" + counterGroup(thisGroup) + " / " + counterGroup(AllGroup) + ")";
}

let count_amont_list1 = document.getElementById("count_amount_list1");
countAmountOf(count_amont_list1, list_prof, Ul);

let subcount_amont_list1_1 = document.getElementById("subcount_amount_list1_1");
countAmountOf(subcount_amont_list1_1, list_prof_artmedia, list_prof);

let subcount_amont_list1_2 = document.getElementById("subcount_amount_list1_2");
countAmountOf(subcount_amont_list1_2, list_prof_it, list_prof);

let subcount_amont_list1_3 = document.getElementById("subcount_amount_list1_3");
countAmountOf(subcount_amont_list1_3, list_prof_traditional, list_prof);

let subcount_amont_list1_4 = document.getElementById("subcount_amount_list1_4");
countAmountOf(subcount_amont_list1_4, list_prof_medicine, list_prof);

let count_amont_list2 = document.getElementById("count_amount_list2");
countAmountOf(count_amont_list2, list_utility, Ul);

let count_amont_list3 = document.getElementById("count_amount_list3");
countAmountOf(count_amont_list3, list_game, Ul);

let count_amont_list3_1 = document.getElementById("subcount_amount_list3_1");
countAmountOf(count_amont_list3_1, list_game_classes, list_game);

let count_amont_list3_2 = document.getElementById("subcount_amount_list3_2");
countAmountOf(count_amont_list3_2, list_game_roles, list_game);

let count_amont_list3_3 = document.getElementById("subcount_amount_list3_3");
countAmountOf(count_amont_list3_3, list_game_chars, list_game);

let count_amont_list3_4 = document.getElementById("subcount_amount_list3_4");
countAmountOf(count_amont_list3_4, list_game_games, list_game);

let count_amont_list4 = document.getElementById("count_amount_list4");
countAmountOf(count_amont_list4, list_service, Ul);

let count_amont_list5 = document.getElementById("count_amount_list5");
countAmountOf(count_amont_list5, list_others, Ul);

let count_amont_list6 = document.getElementById("count_amount_list6");
countAmountOf(count_amont_list6, list_punycode, Ul);

// searching


function searching() {
    let allElements = document.querySelectorAll(".element_for_search");
    let searchInput = document.getElementById('input_search');
    for (let i = 0; i < allElements.length; i++) {
        let element = allElements[i].innerHTML;
        if (searchInput.value === element) {

            window.location = '#' + element;
            alert(`${element} is founded!`);
            break
        } else {
            console.log('fail');
        }
    };
}

// var lastResFind = ""; // последний удачный результат
// var copy_page = ""; // копия страницы в ихсодном виде
// function TrimStr(s) {
//     s = s.replace(/^\s+/g, '');
//     return s.replace(/\s+$/g, '');
// }

// function FindOnPage(inputId) { //ищет текст на странице, в параметр передается ID поля для ввода
//     var obj = window.document.getElementById(inputId);
//     var textToFind;

//     if (obj) {
//         textToFind = TrimStr(obj.value); //обрезаем пробелы
//     } else {
//         alert("Введенная фраза не найдена");
//         return;
//     }
//     if (textToFind == "") {
//         alert("Вы ничего не ввели");
//         return;
//     }

//     if (document.body.innerHTML.indexOf(textToFind) == "-1")
//         alert("Ничего не найдено, проверьте правильность ввода!");

//     if (copy_page.length > 0)
//         document.body.innerHTML = copy_page;
//     else copy_page = document.body.innerHTML;


//     document.body.innerHTML = document.body.innerHTML.replace(eval("/name=" + lastResFind + "/gi"), " "); //стираем предыдущие якори для скрола
//     document.body.innerHTML = document.body.innerHTML.replace(eval("/" + textToFind + "/gi"), "<a name=" + textToFind + " style='background:red'>" + textToFind + "</a>"); //Заменяем найденный текст ссылками с якорем;
//     lastResFind = textToFind; // сохраняем фразу для поиска, чтобы в дальнейшем по ней стереть все ссылки
//     window.location = '#' + textToFind; //перемещаем скрол к последнему найденному совпадению
// }